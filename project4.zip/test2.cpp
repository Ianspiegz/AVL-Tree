#include <iostream>
#include "AVLTree.h"
using namespace std;

int main(){
  AVLTree temp;
  temp.insert("12", "a");
    temp.print();
    cout << "inserting 10 :" << endl;
  temp.insert("10", "b");
    temp.print();
    cout << "inserting 9 :" << endl;
  temp.insert("09", "c");
    temp.print();
    cout << "inserting 8 :" << endl;
  temp.insert("08", "d");
    temp.print();
    cout << "inserting 6 :" << endl;
  temp.insert("06", "d");
    temp.print();
    cout << "inserting 4 :" << endl;
  temp.insert("04", "d");
    temp.print();
    cout << "inserting 2 :" << endl;
  temp.insert("02", "d");
  temp.print();
  cout << "insert 07 " << endl;
  temp.insert("07", "d");
  
  temp.print();
    cout << "level order" << endl;
    temp.levelOrder();
    cout << endl;
  cout << "Delete 12, 10, 09 06" << endl;
  temp.deleteNode("12");
    temp.print();
    cout << "12 deleted" << endl;
  temp.deleteNode("10");
    temp.print();
    cout << "10 deleted" << endl;
  temp.deleteNode("09");
    temp.print();
    cout << "9 deleted" << endl;
  temp.deleteNode("06");
    cout << "6 deleted:" << endl;
  temp.print();
}
